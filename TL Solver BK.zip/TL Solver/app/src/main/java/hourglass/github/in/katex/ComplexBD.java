package hourglass.github.in.katex;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;

import java.math.BigDecimal;

import katex.hourglass.in.mathlib.MathView;

public class ComplexBD extends AppCompatActivity {
    public final BigDecimal re;   // the real part
    public final BigDecimal im;   // the imaginary part

    // create a new object with the given real and imaginary parts
    public ComplexBD(BigDecimal real, BigDecimal imag) {
        re = real;
        im = imag;
    }

    // return a string representation of the invoking Complex object
    public String toString() {
        if (im.compareTo(BigDecimal.ZERO) == 0) return re + "";
        if (re.compareTo(BigDecimal.ZERO) == 0) return im + "i";
        if (im.compareTo(BigDecimal.ZERO) <  0) return re + " - " + (im.negate()) + "i";
        return re + " + " + im + "i";
    }

    // return a new Complex object whose value is (this * b)
    public ComplexBD times(ComplexBD b) {
        ComplexBD a = this;

        // check which variables are available.
        BigDecimal one = a.re;
        BigDecimal two = a.im;
        BigDecimal three = b.re;
        BigDecimal four = b.im;

        // If all 4 variables are present
        if(one != null && two != null && three != null && four != null){
            BigDecimal real = (a.re.multiply(b.re)).subtract(a.im.multiply(b.im));
            BigDecimal imag = (a.re.multiply(b.im)).add(a.im.multiply(b.re));
            return new ComplexBD(real, imag);
        }
//        // If 2 (real) variables are present
//        if(one != null && three != null){
//            BigDecimal real = (a.re.multiply(b.re));
//            return new ComplexBD(real, null);
//        }
        return null;

    }

    public String times_showSteps(ComplexBD b){
        ComplexBD a = this;
        String steps = "";

//        step 1 a = a.re, b = a.im, c = b.re, d = b.im
//        steps += "Step 1: Apply complex arithmetic rule: (a+bi)(c+di) = (ac-bd)+(ad+bc)i \n";
//        steps += "(" + a.re + " * " + b.re + " - " + a.im + " * " + b.im + ") + (" + a.re + " * " + b.im + " + " + a.im + " * " + b.re + ")i \n";
//        steps += "Step 2: Expand \n";
//        steps += "(" + a.re.multiply(b.re) + " - " + a.im.multiply(b.im) + ") + (" + a.re.multiply(b.im) + " + " + a.im.multiply(b.re) + ")i\n" ;
//        steps += "Step 3: Simplify \n";
//        steps += "(" + (a.re.multiply(b.re)).subtract(a.im.multiply(b.im)) + ") + (" + (a.re.multiply(b.im)).add(a.im.multiply(b.re)) + ")i" ;

        return steps;
    }
}
